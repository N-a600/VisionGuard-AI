import React from "react";

export default function Dashboard() {
  return (
    <div className="p-6 min-h-screen bg-white text-gray-800">
      <h1 className="text-2xl font-bold mb-4">Tableau de vision</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-green-100 shadow">
          <h2 className="font-semibold">Santé visuelle actuelle</h2>
          <div className="mt-2 text-4xl">🟢</div>
        </div>
        <div className="p-4 rounded-xl bg-blue-100 shadow">
          <h2 className="font-semibold">Qualité de l'air</h2>
          <p className="mt-2">Bonne</p>
        </div>
        <div className="p-4 rounded-xl bg-yellow-100 shadow">
          <h2 className="font-semibold">Lumière ambiante</h2>
          <p className="mt-2">Modérée</p>
        </div>
        <div className="p-4 rounded-xl bg-pink-100 shadow">
          <h2 className="font-semibold">Conseil du jour</h2>
          <p className="mt-2">Faites une pause oculaire maintenant 👓</p>
        </div>
      </div>
    </div>
  );
}