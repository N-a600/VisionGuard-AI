import React from "react";

export default function Trends() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Tendances</h1>
      <p>Graphiques dynamiques en cours de développement…</p>
    </div>
  );
}