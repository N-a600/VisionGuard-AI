import React from "react";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-blue-900 to-blue-600 text-white p-6">
      <div className="text-center">
        <div className="mb-4">
          <div className="w-24 h-24 bg-white rounded-full mx-auto mb-4 flex items-center justify-center text-blue-800 text-3xl font-bold">
            👁️
          </div>
          <h1 className="text-3xl font-bold mb-2">VISIONGUARD AI</h1>
          <p className="text-lg italic">Nous protégeons votre vue… avant que les yeux ne la voient.</p>
        </div>
        <button
          onClick={() => navigate("/dashboard")}
          className="mt-6 px-6 py-2 bg-white text-blue-900 font-semibold rounded-full shadow-md hover:bg-gray-100 transition"
        >
          Entrer
        </button>
        <div className="mt-6 text-sm opacity-80">Langue : Français 🇫🇷</div>
      </div>
    </div>
  );
}