import React from "react";

export default function VisionMap() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Carte de la vision mondiale</h1>
      <p>Zones affectées par la pollution et les conditions lumineuses…</p>
    </div>
  );
}