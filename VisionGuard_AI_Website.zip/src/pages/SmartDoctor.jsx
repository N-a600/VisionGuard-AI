import React from "react";

export default function SmartDoctor() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Docteur intelligent</h1>
      <p>Analyse des données personnelles et environnementales…</p>
      <p className="mt-2 italic">Fonctionnalité IA à venir.</p>
    </div>
  );
}