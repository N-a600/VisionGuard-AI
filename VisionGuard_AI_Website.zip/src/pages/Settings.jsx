import React from "react";

export default function Settings() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Paramètres</h1>
      <ul className="list-disc list-inside">
        <li>Changer la langue</li>
        <li>Activer le mode malvoyant</li>
        <li>Connexion avec des appareils intelligents</li>
      </ul>
    </div>
  );
}